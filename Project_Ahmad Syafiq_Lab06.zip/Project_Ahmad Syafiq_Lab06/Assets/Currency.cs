﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Currency : MonoBehaviour
{
    private float Eur = 0.63f;

    public InputField AmountInput;
    private string InputTxt;
    private string AmountResult;

    public Toggle USDCur;
    public Toggle EURCur;


    public void CurrencyChange()
    {


        if (EURCur.enabled)
        {

        }
    }
}
