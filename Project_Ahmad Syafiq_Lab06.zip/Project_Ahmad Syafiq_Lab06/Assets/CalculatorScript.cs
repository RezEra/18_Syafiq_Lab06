﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalculatorScript : MonoBehaviour
{
    public float Amount;

    //Iqmals Currency
    public float SGDRM = 3.27f;
    public float SGDIDR = 11447.60f;

    public Toggle RM;
    public Toggle IDR;
    

    //Syafiq Currency
    public float SGDUSD = 0.76f;
    public float SGDEUR = 0.63f;

    public Toggle USD;
    public Toggle EUR;

    public InputField InputAmount;
    public InputField InputConverted;

    // Start is called before the first frame update
    void Start()
    {
        //Iqmals Code
        RM.isOn = false;
        IDR.isOn = false;
        

        //Syafiq Code
        USD.isOn = false;
        EUR.isOn = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Conversion()
    {
        float Amount = float.Parse(InputAmount.text);

        //Iqmals Code
        if(RM.isOn == true)
        {
            IDR.isOn = false;

            InputConverted.text = "RM " + (Amount * SGDRM);
        }
        else if(IDR.isOn == true)
        {
            RM.isOn = false;

            InputConverted.text = "Rupiah " + (Amount * SGDIDR);
        }
        

        //Syafiq Code
        if (USD.isOn == true)
        {
            EUR.isOn = false;

            InputConverted.text = "$ " + (Amount * SGDUSD);
        }
        else if (EUR.isOn == true)
        {
            USD.isOn = false;

            InputConverted.text = "£ " + (Amount * SGDEUR);
        }
    }

    public void Clear()
    {
        RM.isOn = false;
        IDR.isOn = false;
        USD.isOn = false;
        EUR.isOn = false;

        InputAmount.text = " ";
        InputConverted.text = " ";
    }

}
